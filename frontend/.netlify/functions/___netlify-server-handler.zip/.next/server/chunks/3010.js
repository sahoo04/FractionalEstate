"use strict";exports.id=3010,exports.ids=[3010],exports.modules={23010:(r,s,e)=>{e.r(s),e.d(s,{cursorSvg:()=>t});var o=e(48396);let t=o.YP` <svg fill="none" viewBox="0 0 13 4">
  <path fill="currentColor" d="M.5 0h12L8.9 3.13a3.76 3.76 0 0 1-4.8 0L.5 0Z" />
</svg>`}};